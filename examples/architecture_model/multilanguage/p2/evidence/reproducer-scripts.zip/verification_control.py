import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

engine = Path("F:/CodeBoarding")
out = engine / "temp/m5-p2/verification-control"
out.mkdir(exist_ok=False)
model = json.loads((engine / "examples/architecture_model/multilanguage/model/revision-2.json").read_text())
backend = next(item for item in model["facts"] if item["source_root_id"] == "backend")
for label, cwd in (("old", engine/"temp/m5-p2/review-head"), ("fixed", engine)):
    path = out / f"{label}.json"
    path.write_text(json.dumps(model,indent=2)+"\n", encoding="utf-8")
    for target in ("invoke", "read-file-ipc"):
        current = json.loads(path.read_text())
        record = {"id": "wrong-"+target, "status":"planned", "object_ids":[target], "command":"not executed", "environment":"reproduction", "inputs":"cross-root version mismatch or unscoped contract", "source_version":backend["source"]["digest"]}
        patch = out / f"{label}-{target}.patch.json"
        patch.write_text(json.dumps({"author":"P2 reproduction","summary":"Reproduce verification scope defect","operations":[{"action":"create","collection":"verifications","id":record["id"],"value":record}]}),encoding="utf-8")
        before = path.read_bytes()
        command = [sys.executable,"-m","architecture_model","model","--file",str(path),"apply","--patch",str(patch),"--expected-revision",str(current["revision"])]
        result = subprocess.run(command,cwd=cwd,capture_output=True,text=True)
        (out/f"{label}-{target}.response.json").write_text(result.stdout,encoding="utf-8")
        if label == "old":
            assert result.returncode == 0
        else:
            assert result.returncode == 1 and "VERIFICATION_SCOPE" in result.stdout
            assert path.read_bytes() == before
        (out/f"{label}-{target}.check.json").write_text(json.dumps({"command":command,"exit_code":result.returncode,"before_sha256":hashlib.sha256(before).hexdigest(),"after_sha256":hashlib.sha256(path.read_bytes()).hexdigest()},indent=2)+"\n",encoding="utf-8")
