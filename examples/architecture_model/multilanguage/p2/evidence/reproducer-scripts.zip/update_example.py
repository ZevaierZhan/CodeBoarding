import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path("F:/CodeBoarding")
folder = root / "examples/architecture_model/multilanguage"
out = folder / "p2"
model_path = folder / "model/model.json"
model = json.loads(model_path.read_text(encoding="utf-8"))
assert model["revision"] == 10
binding = next(item for item in model["bindings"] if item["id"] == "invoke")
command = [sys.executable, str(out / "check_frontend.py"), "--source", str(folder / "source-current/frontend/src/utils.ts"), "--sha256", binding["location"]["content_hash"]]
result = subprocess.run(command, capture_output=True, text=True, check=True)
(out / "frontend-execution.json").write_text(result.stdout, encoding="utf-8")
partial = {"id": "p2-frontend-source-check", "status": "executed", "object_ids": ["read-file-ipc"], "command": subprocess.list2cmdline(command), "environment": "Acceptance workstation; source-only check, no desktop host", "inputs": "Exact source-current/frontend/src/utils.ts file; declared IPC literal", "source_version": binding["source_version"], "binding_snapshots": {"invoke": binding["snapshot_id"]}, "executor": "M5 external Agent", "executed_at": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode, "result": result.stdout.strip()}
bindings = {item["id"]: item for item in model["bindings"]}
planned = {"id": "p2-planned-ipc-check", "status": "planned", "object_ids": ["read-file-ipc"], "command": "Start a desktop host and exercise read_file IPC against both declared source versions", "environment": "Desktop host and feature build required; not executed", "inputs": "Frontend invoke, Rust command and handler registration", "source_version": binding["source_version"], "binding_snapshots": {identity: bindings[identity]["snapshot_id"] for identity in ("invoke", "command", "registration")}}
patch = {"author": "M5 external Agent", "summary": "Record executed frontend-only evidence check and planned bilateral IPC check without promoting the candidate contract", "operations": [{"action": "create", "collection": "verifications", "id": item["id"], "value": item} for item in (partial, planned)]}
patch_file = out / "verification.patch.json"
patch_file.write_text(json.dumps(patch, indent=2)+"\n", encoding="utf-8")
prefix = [sys.executable, "-m", "architecture_model", "model", "--file", str(model_path)]
for action, extra in (("validate", []), ("diff", []), ("apply", ["--expected-revision", "10"])):
    done = subprocess.run([*prefix, action, "--patch", str(patch_file), *extra], capture_output=True, text=True, check=True)
    (out / f"{action}.json").write_text(done.stdout, encoding="utf-8")
after = json.loads(model_path.read_text(encoding="utf-8"))
assert all(after[key] == model[key] for key in ("facts", "bindings", "components", "relations", "scenarios", "maintenance"))
(out / "preservation.json").write_text(json.dumps({"before_revision":10,"after_revision":after["revision"],"old_facts_bindings_interpretations_reviews_unchanged":True,"ipc_status":next(item["contract"]["status"] for item in after["relations"] if item["id"]=="read-file-ipc")},indent=2)+"\n",encoding="utf-8")
mapping = out / "source-map.json"
mapping.write_text(json.dumps({"frontend":str(folder/"source-current/frontend"),"backend":str(folder/"source/backend")}),encoding="utf-8")
done = subprocess.run([*prefix,"export-html","--output",str(out/"index.html"),"--source-map",str(mapping)],capture_output=True,text=True,check=True)
(out/"export.json").write_text(done.stdout,encoding="utf-8")
(folder/"model/index.html").write_bytes((out/"index.html").read_bytes())
