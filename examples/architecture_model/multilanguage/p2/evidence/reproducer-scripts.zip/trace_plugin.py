import json
import os
from pathlib import Path


def pytest_runtest_logreport(report):
    if report.when == "call" or report.failed:
        with Path(os.environ["M5_REPORT"]).open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"nodeid": report.nodeid, "outcome": report.outcome, "trace": str(report.longrepr)}) + "\n")
