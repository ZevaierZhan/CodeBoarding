import concurrent.futures
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ENGINE = Path("F:/CodeBoarding")
OUT = ENGINE / "temp/m5-p2/attribution"
OUT.mkdir(parents=True, exist_ok=True)
original = (ENGINE / "temp/m5/full-suite.log").read_text(encoding="utf-8")
nodes = re.findall(r"^FAILED (tests/.*)$", original, re.M)
assert len(nodes) == len(set(nodes)) == 122
headers = list(re.finditer(r"^_{2,} (.+?) _{2,}\s*$", original, re.M))
records = []
for node in nodes:
    leaf = node.split("::")[-1]
    classname = node.split("::")[-2] if node.count("::") > 1 else ""
    match = next((item for item in headers if leaf in item.group(1) and (not classname or classname in item.group(1))), None)
    section = ""
    if match:
        index = headers.index(match)
        end = headers[index+1].start() if index+1 < len(headers) else original.find("tests coverage", match.end())
        section = original[match.end():end]
    errors = re.findall(r"^E\s+(.+)", section, re.M)
    types = re.findall(r"(?:^|\s)([\w.]+(?:Error|Expired|Failed))[:(]", "\n".join(errors))
    records.append({"nodeid": node, "original_failure_type": types[0] if types else "unparsed", "original_error": errors[0][:600] if errors else ""})
    (OUT / "original-failures.json").write_text(json.dumps(records, indent=2), encoding="utf-8")

groups = {}
for node in nodes:
    groups.setdefault(node.split("::")[0], []).append(node)

def run_case(job):
    label, file, targets = job
    name = file.removeprefix("tests/").replace("/", "_").removesuffix(".py")
    root = ENGINE / "temp/m5-p2" / label
    output = OUT / label
    output.mkdir(exist_ok=True)
    xml = output / f"{name}.xml"
    selectors = list(dict.fromkeys(target.split("[")[0] if " " in target else target for target in targets))
    command = [sys.executable, "-m", "pytest", *selectors, "--no-cov", "-q", "--tb=short", f"--junitxml={xml}", "-o", f"cache_dir={output / 'cache'}"]
    try:
        process = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=150)
        log = process.stdout + process.stderr
        code = process.returncode
    except subprocess.TimeoutExpired as error:
        log = "GROUP TIMED OUT after 150 seconds\n" + str(error.stdout or b"") + str(error.stderr or b"")
        code = "timeout"
    (output / f"{name}.log.gz").write_bytes(gzip.compress(log.encode("utf-8"), mtime=0))
    cases = {}
    if xml.exists():
        for case in ET.parse(xml).iter("testcase"):
            short = case.attrib["name"]
            failure = case.find("failure")
            if failure is None:
                failure = case.find("error")
            cases[short] = {"outcome": "failed" if failure is not None else "skipped" if case.find("skipped") is not None else "passed", "message": failure.attrib.get("message", "") if failure is not None else "", "trace": failure.text if failure is not None else ""}
    result = {"label": label, "file": file, "exit_code": code, "command": command, "cases": cases}
    (output / f"{name}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"label": label, "file": file, "code": code, "cases": len(cases)}), flush=True)
    return result

if __name__ == "__main__":
    jobs = [(label, file, targets) for file, targets in groups.items() for label in ("base-main", "review-head")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run_case, jobs))
    (OUT / "runs.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
