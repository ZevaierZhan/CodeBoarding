import collections
import gzip
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

out = Path("F:/CodeBoarding/temp/m5-p2/attribution")
source = Path("F:/CodeBoarding/temp/m5/full-suite.log").read_text(encoding="utf-8")
nodes = re.findall(r"^FAILED (tests/.*)$", source, re.M)
headers = [match for match in re.finditer(r"^_+ (.+?) _+\s*$", source, re.M) if re.search("[A-Za-z]", match.group(1)) and not match.group(1).startswith("coverage:")]
assert len(nodes) == len(headers) == 122


def failure_type(trace):
    matches = re.findall(r"(?:^E\s+|^|:\s+)([\w.]+(?:Error|Expired|Failed))(?::|\b)", trace, re.M)
    return matches[0] if matches else "AssertionError" if "assert" in trace.lower() else "unparsed"


def normalize(node):
    return re.sub(r"\\{2,}", r"\\", node)


def stable_message(node, message):
    message = re.sub(r"tmp[a-z0-9]{8}", "tmp<fixture>", message)
    message = re.sub(r"pytest-\d+", "pytest-<run>", message)
    message = re.sub(r"0x[0-9A-Fa-f]+", "0x<address>", message)
    if "test_extends_wait_when_diagnostics_keep_arriving" in node:
        message = re.sub(r"<= \d+\.\d+", "<= <elapsed>", message)
    return message


cases = {}
for label in ("base-main", "review-head"):
    entries = {}
    for file in (out / label).glob("*.xml"):
        for case in ET.parse(file).iter("testcase"):
            classname = case.attrib["classname"]
            bits = classname.split(".")
            class_parts = []
            while bits and not bits[-1].startswith("test_"):
                class_parts.insert(0, bits.pop())
            path = "/".join(bits) + ".py"
            node = path + "::" + "::".join([*class_parts, case.attrib["name"]])
            failure = case.find("failure")
            if failure is None:
                failure = case.find("error")
            entries[normalize(node)] = {"outcome": "failed" if failure is not None else "skipped" if case.find("skipped") is not None else "passed", "type": failure_type(failure.attrib.get("message", "") + "\n" + (failure.text or "")) if failure is not None else "", "message": failure.attrib.get("message", "")[:800] if failure is not None else ""}
    for file in (out / label).glob("retry-*.json"):
        result = json.loads(file.read_text(encoding="utf-8"))
        for report in result["reports"]:
            entries[normalize(report["nodeid"])] = {"outcome": report["outcome"], "type": failure_type(report["trace"]) if report["outcome"] == "failed" else "", "message": report["trace"][:4000] + report["trace"][-2000:]}
        if normalize(result["nodeid"]) not in entries:
            entries[normalize(result["nodeid"])] = {"outcome": str(result["exit_code"]), "type": "timeout", "message": result.get("timeout_trace", "")[:6000]}
    cases[label] = entries

rows = []
for index, node in enumerate(nodes):
    end = headers[index+1].start() if index+1 < len(headers) else source.index("tests coverage", headers[index].end())
    section = source[headers[index].end():end]
    errors = re.findall(r"^E\s+(.+)$", section, re.M)
    before = cases["base-main"].get(normalize(node), {"outcome": "not_completed", "type": "", "message": "group budget expired before a structured result"})
    head = cases["review-head"].get(normalize(node), {"outcome": "not_completed", "type": "", "message": "group budget expired before a structured result"})
    if all(item["outcome"] == "failed" and "WinError 1314" in item["message"] for item in (before, head)):
        category = "environment"
        reason = "Both fail during symlink fixture setup because the Windows token lacks the required privilege"
    elif node.endswith("test_post_create_script_bash_syntax") and before["outcome"] == head["outcome"] == "failed":
        category = "environment"
        reason = "Both fail to execute bash (exit 127); host/WSL prerequisite unavailable"
    elif all(item["outcome"] in ("failed", "timeout") and any(word in item["message"] for word in ("tree_sitter_language_pack", "kotlin_language", "Kotlin tree-sitter grammar")) for item in (before, head)):
        category = "environment"
        reason = "Both blocked in Kotlin grammar loader/download; assertions after dependency setup remain unverified"
    elif before["outcome"] == head["outcome"] == "failed":
        category = "baseline_existing" if before["type"] == head["type"] and stable_message(node, before["message"]) == stable_message(node, head["message"]) else "unattributed"
        reason = "Same test, failure type and normalized failure message on clean main and review head; only fixture IDs, addresses and actual elapsed values normalized" if category == "baseline_existing" else "Both fail with differing types/messages; needs further investigation"
    elif before["outcome"] == "passed" and head["outcome"] == "failed":
        category = "pr_introduced"
        reason = "Clean main passes; review head fails"
    elif before["outcome"] == head["outcome"] == "passed":
        category = "environment"
        reason = "Both clean archives pass; original workspace/environment failure does not reproduce"
    elif before["outcome"] == head["outcome"] == "timeout" and all(any(word in item["message"] for word in ("tree_sitter_language_pack", "download_asset", "requests\\", "urllib3")) for item in (before, head)):
        category = "environment"
        reason = "Both blocked in grammar/dependency download before a result; original assertion remains unverified with prerequisites restored"
    else:
        category = "unattributed"
        reason = "No comparable completed pair"
    row = {"nodeid": node, "original_failure_type": failure_type(section), "original_error": errors[0][:600] if errors else section[-600:], "category": category, "reason": reason, "base_main": before, "review_head": head}
    rows.append(row)
counter = collections.Counter(row["category"] for row in rows)
(out / "classification.json").write_text(json.dumps({"base":"4f73e07c46b21a1fc96426b4be9bf9ff96e8a7dd", "review_head":"1f165caa0fccbaaf700c9af96159367c21bf06bd", "counts":{key:counter[key] for key in ("pr_introduced","baseline_existing","environment","unattributed")}, "failures":rows},indent=2)+"\n",encoding="utf-8")
print(collections.Counter(row["category"] for row in rows))
print("Unparsed original types", sum(row["original_failure_type"] == "unparsed" for row in rows))
for row in rows:
    if row["category"] in ("pr_introduced", "unattributed"):
        print(row["nodeid"], row["base_main"]["outcome"], row["review_head"]["outcome"])
