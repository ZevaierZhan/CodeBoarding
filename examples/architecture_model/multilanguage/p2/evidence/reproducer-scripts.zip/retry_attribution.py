import concurrent.futures
import hashlib
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path("F:/CodeBoarding")
out = root / "temp/m5-p2/attribution"
records = json.loads((out / "original-failures.json").read_text())
runs = json.loads((out / "runs.json").read_text())
files = {item["file"] for item in runs if item["exit_code"] == "timeout"}


def run(job):
    label, node = job
    name = "retry-" + hashlib.sha256(node.encode()).hexdigest()[:12]
    report = out / label / f"{name}.jsonl"
    selector = node
    if " " in node:
        collected = (root / "temp/m5-p2/collect-params.log").read_text(encoding="utf-8").splitlines()
        normalize = lambda value: value.replace("\\\\", "\\")
        selector = next(line for line in collected if normalize(line) == normalize(node))
    if sys.argv[1:]:
        report.write_text("",encoding="utf-8")
    command = [sys.executable, "-m", "pytest", selector, "--no-cov", "-q", "--tb=short", "-p", "trace_plugin", "-o", "faulthandler_timeout=15", "-o", f"cache_dir={out/label/'retry-cache'}"]
    env = os.environ | {"M5_REPORT": str(report), "PYTHONPATH": str(root / "temp/m5-p2"), "PYTHONUNBUFFERED": "1"}
    process = subprocess.Popen(command, cwd=root / "temp/m5-p2" / label, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        stdout, stderr = process.communicate(timeout=35)
        code = process.returncode
    except subprocess.TimeoutExpired:
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, timeout=10)
        stdout, stderr = process.communicate(timeout=10)
        code = "timeout"
    (out / label / f"{name}.log.gz").write_bytes(gzip.compress((stdout+stderr).encode(),mtime=0))
    result = {"nodeid": node, "label": label, "exit_code": code, "command": command, "reports": [json.loads(line) for line in report.read_text().splitlines()] if report.exists() else [], "timeout_trace": (stdout+stderr)[-10000:] if code == "timeout" else ""}
    (out / label / f"{name}.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps({"label":label,"node":node,"code":code}),flush=True)
    return result


jobs = [(label, record["nodeid"]) for record in records if record["nodeid"].split("::")[0] in files for label in ("base-main", "review-head")]
if sys.argv[1:]:
    jobs = [job for job in jobs if "test_runtime_references_exclude_bindings_and_annotations[kt-" in job[1]]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, jobs))
(out / "retry-runs.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
