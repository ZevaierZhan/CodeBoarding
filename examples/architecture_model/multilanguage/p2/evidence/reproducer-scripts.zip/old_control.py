import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path("F:/CodeBoarding")
out = root / "temp/m5-p2/legacy-control"
out.mkdir(exist_ok=False)
shutil.copyfile(root / "temp/m5-p2/legacy-live/before.json", out / "model.json")
prefix = [sys.executable, "-m", "architecture_model", "model", "--file", str(out / "model.json")]
cwd = root / "temp/m5-p2/review-head"


def invoke(name, arguments):
    result = subprocess.run([*prefix, *arguments], cwd=cwd, capture_output=True, text=True, check=True)
    (out / f"{name}.json").write_text(result.stdout, encoding="utf-8")
    return json.loads(result.stdout)["result"]


before = invoke("before-query", ["maintenance"])
target = root / "temp/m5-p2/native/frontend.facts.json"
report = invoke("preview", ["maintenance-preview", "--facts", str(target)])
model = json.loads((out / "model.json").read_text())
invoke("refresh", ["maintenance-refresh", "--facts", str(target), "--token", report["token"], "--expected-revision", str(model["revision"]), "--author", "P2 reproduction"])
after = invoke("after-query", ["maintenance"])
invoke("html", ["export-html", "--output", str(out / "after.html")])
assert before["latest_target_snapshot_id"] != after["latest_target_snapshot_id"]
assert after["latest_target_snapshot_id"] == json.loads(target.read_text())["id"]
(out / "reproduced.json").write_text(json.dumps({"review_head":"1f165caa0fccbaaf700c9af96159367c21bf06bd", "legacy_L":before["latest_target_snapshot_id"], "wrong_legacy_after_v2_refresh_R":after["latest_target_snapshot_id"], "legacy_mislabeled_older":True},indent=2)+"\n",encoding="utf-8")
