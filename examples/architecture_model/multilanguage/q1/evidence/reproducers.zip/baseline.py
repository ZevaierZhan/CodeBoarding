import tree_sitter_language_pack as pack
import pytest

original = pack.get_language

def offline_language(name):
    if name not in pack.downloaded_languages():
        raise RuntimeError(f'Q1 offline baseline: {name} grammar absent; download blocked before loader')
    return original(name)

pack.get_language = offline_language
if __name__ == '__main__':
    raise SystemExit(pytest.main(['--cov=.', '--cov-report=term', '--cov-report=json:temp/q1/coverage-baseline.json', '--cov-fail-under=80', '--junitxml=temp/q1/baseline.xml']))
