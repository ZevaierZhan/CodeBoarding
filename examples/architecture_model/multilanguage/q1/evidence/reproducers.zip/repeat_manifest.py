import json
import subprocess
import sys
from pathlib import Path

if __name__ == '__main__':
    root=Path(__file__).resolve().parents[2]
    node='tests/infra/test_tool_registry.py::TestManifest::test_write_manifest_overwrites_existing_file'
    results=[]
    for index in range(20):
        result=subprocess.run([sys.executable,'-m','pytest',node,'-q','--tb=short'],cwd=root,capture_output=True,text=True,timeout=45)
        results.append({'run':index+1,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    dest=root/'examples/architecture_model/multilanguage/q1/evidence/manifest-repeats.json'
    dest.write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps({'runs':len(results),'passed':sum(r['returncode']==0 for r in results),'failed':sum(r['returncode']!=0 for r in results)}))
