from pathlib import Path
import tree_sitter_language_pack as pack
import pytest

calls = []
def forbidden(*args, **kwargs):
    calls.append((args, kwargs))
    raise AssertionError('Collection must not load or download optional grammars')
pack.get_language = forbidden
pack.download = forbidden
status = pytest.main(['--collect-only', '-q', 'tests'])
assert not calls, calls
print('No grammar load or download API called during collection')
raise SystemExit(status)
