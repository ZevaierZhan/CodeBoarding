import gzip
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
E = ROOT / 'examples/architecture_model/multilanguage/q1/evidence'

def read(name):
    cases = {}
    for t in ET.parse(E / (name + '.xml')).findall('.//testcase'):
        parts = t.get('classname', '').split('.')
        index = max(i for i, part in enumerate(parts) if part.startswith('test_'))
        nodeid = '/'.join(parts[:index + 1]) + '.py::' + '::'.join(parts[index + 1:] + [t.get('name')])
        error = t.find('failure')
        skip = t.find('skipped')
        if error is None:
            error = t.find('error')
        cases[nodeid] = {'outcome': 'failed' if error is not None else 'skipped' if skip is not None else 'passed', 'reason': error.get('message', '') if error is not None else skip.get('message', '') if skip is not None else ''}
    return cases

def counts(cases):
    return dict(Counter(v['outcome'] for v in cases.values()))

baseline, final, analyzers, model = [read(n) for n in ('baseline', 'final', 'analyzers', 'model-native')]
old = json.loads((ROOT / 'examples/architecture_model/multilanguage/p2/evidence/failure-classification.json').read_text())
changes = []
for nodeid in sorted(set(baseline) | set(final)):
    before, after = baseline.get(nodeid, {'outcome': 'not_collected'}), final.get(nodeid, {'outcome': 'not_collected'})
    if before['outcome'] == 'failed' or after['outcome'] == 'failed':
        historical = next((f for f in old['failures'] if f['nodeid'] == nodeid), {})
        changes.append({'nodeid': nodeid, 'baseline': before, 'final': after, 'm5_classification': historical.get('category', 'not_in_m5_122')})
old_status = [{'nodeid': f['nodeid'], 'm5_category': f['category'], 'baseline': baseline.get(f['nodeid'], {'outcome': 'not_collected'}), 'final': final.get(f['nodeid'], {'outcome': 'not_collected'})} for f in old['failures']]
coverage = json.loads((ROOT / 'temp/q1/coverage-final.json').read_text())
modules = {}
for prefix in ('static_analyzer/', 'architecture_model/', 'infra/repo_utils/', 'diagram_analysis/'):
    entries = [v['summary'] for k, v in coverage['files'].items() if k.replace('\\', '/').startswith(prefix)]
    total = sum(v['num_statements'] for v in entries)
    covered = sum(v['covered_lines'] for v in entries)
    modules[prefix] = {'covered_lines': covered, 'statements': total, 'percent': round(100 * covered / total, 2) if total else 0}
resolved = [v for v in changes if v['baseline']['outcome'] == 'failed' and v['final']['outcome'] == 'passed']
kotlin = [k for k, v in final.items() if v['outcome'] == 'skipped' and 'Kotlin grammar is not installed' in v['reason']]
remaining = []
for row in changes:
    if row['final']['outcome'] != 'failed':
        continue
    nodeid = row['nodeid']
    issue = 'Installer portability assertion or fixture; native analyzer scope passes. Review Windows setup behavior separately.' if 'test_tool_registry' in nodeid else 'The available bash command is the WSL launcher; a Windows path is not usable as a Linux script path. Verify with a working bash and path mapping.'
    remaining.append({'nodeid': nodeid, 'priority': 'P2' if 'EndToEnd' in nodeid or 'node_tools' in nodeid else 'P3', 'reproduce': 'uv run pytest ' + nodeid + ' -q --tb=short', 'baseline_existing': row['baseline']['outcome'] == 'failed', 'impact': issue, 'actual_error': row['final']['reason'], 'status': 'unresolved; assertions retained, not skipped'})
summary = {'base_main': 'cca03766', 'm5_merge': '7d38098c3ae975ced36ad67887355efd4fd34a05', 'baseline': counts(baseline), 'final': counts(final), 'analyzers': counts(analyzers), 'model_native': counts(model), 'baseline_failed_to_passed': len(resolved), 'kotlin_skipped': len(kotlin), 'baseline_uri_errors': sum('relative path can' in v['reason'] and 'file URI' in v['reason'] for v in baseline.values()), 'final_uri_errors': sum('relative path can' in v['reason'] and 'file URI' in v['reason'] for v in final.values()), 'new_test_cases': len(set(final) - set(baseline)), 'm5_122_baseline': dict(Counter(v['baseline']['outcome'] for v in old_status)), 'm5_122_final': dict(Counter(v['final']['outcome'] for v in old_status)), 'global_coverage_percent': coverage['totals']['percent_covered'], 'module_coverage': modules, 'coverage_gate': 80, 'coverage_gate_passed': coverage['totals']['percent_covered'] >= 80, 'executable_without_missing_kotlin': {'passed': counts(final).get('passed', 0), 'failed': counts(final).get('failed', 0), 'other_skipped': counts(final).get('skipped', 0) - len(kotlin)}, 'linux': {'scope': '10 stdlib path/URI checks only', 'full_pytest': 'not run; available Python 3.13.5 outside project >=3.12,<3.13 constraint'}, 'domain_model_diff': subprocess.check_output(['git', 'diff', '--name-only', 'origin/main', '--', 'architecture_model', 'tests/architecture_model'], cwd=ROOT, text=True).strip()}
for name, data in [('summary.json', summary), ('status-changes.json', changes), ('m5-122-status.json', old_status), ('remaining-issues.json', remaining), ('kotlin-skips.json', [{'nodeid': k, **final[k]} for k in kotlin]), ('environment.json', {'platform': platform.platform(), 'python': sys.version, 'venv': sys.prefix, 'workspace': str(ROOT), 'env_file_exists': (ROOT / '.env').is_file(), 'optional_native_tools': 'explicit local M1_*/M5_TOOLS config; no installation', 'baseline_command': 'uv run python temp/q1/baseline.py (no-download loader guard)', 'final_command': 'uv run --no-sync pytest --cov=. --cov-report=term --cov-fail-under=80', 'native_command': 'uv run --no-sync pytest tests/architecture_model -q with explicit native tool env', 'worktree_note': 'Isolated from concurrent business-permission-matrix edits; original baseline workspace contained ignored historical temp outputs.'})]:
    (E / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
with gzip.open(E / 'all-test-status.json.gz', 'wt', encoding='utf-8') as f:
    json.dump({'baseline': baseline, 'final': final, 'analyzers': analyzers, 'model_native': model}, f, ensure_ascii=False)
print(json.dumps(summary, indent=2))
