import json
import platform
import runpy
import tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
paths = runpy.run_path(str(root / 'infra/repo_utils/path_utils.py'))
uri = runpy.run_path(str(root / 'static_analyzer/engine/utils.py'))['uri_to_path']
cases = [('/repo/src/a.py', '/repo', 'src/a.py'), ('C:/repo/src/a b.py', 'C:/repo', 'src/a b.py'), ('C:/repo/a.py', 'c:/REPO', 'a.py'), ('D:/repo/a.py', 'C:/repo', 'D:/repo/a.py'), ('/repo/a\\b.py', '/repo', 'a\\b.py')]
for file, repo, expected in cases:
    assert paths['normalize_repo_path'](file, repo) == expected, (file, repo)
with tempfile.TemporaryDirectory() as directory:
    repo = Path(directory)
    file = repo / 'src' / 'a #%.py'
    assert paths['to_relative_path'](file, repo) == 'src/a #%.py'
    assert Path(paths['to_absolute_path']('src/a #%.py', repo)) == file
    assert uri(file.as_uri()) == file
assert uri('file:relative.py') is None
assert uri('file://foreign-server/share/file.py') is None
print(json.dumps({'platform': platform.platform(), 'python': platform.python_version(), 'checks': 10, 'status': 'passed', 'scope': 'stdlib path and URI helpers only; not the Linux pytest suite'}))
