import json
import tempfile
from pathlib import Path
from static_analyzer.analysis_cache import StaticAnalysisCache
from static_analyzer.analysis_result import StaticAnalysisResults
from static_analyzer.config import Language

with tempfile.TemporaryDirectory() as folder:
    root=Path(folder)
    literal=root/'a\\b.py'
    nested=root/'a/b.py'
    nested.parent.mkdir()
    literal.write_text('literal')
    nested.write_text('nested')
    result=StaticAnalysisResults()
    result.add_source_files(Language.PYTHON,[str(literal),str(nested)])
    cache=StaticAnalysisCache(root/'.codeboarding',root)
    cache.save(result,source_sha='source')
    loaded=cache.get(expected_sha='source')
    paths=loaded.get_source_files(Language.PYTHON)
    print(json.dumps({'original':[str(literal),str(nested)],'restored':paths,'distinct_restored_identities':len(set(paths)),'contents':[Path(p).read_text() for p in paths]}))
    assert len(set(paths))==2 and Path(paths[0]).samefile(literal), 'Cache merged distinct POSIX file identities'
