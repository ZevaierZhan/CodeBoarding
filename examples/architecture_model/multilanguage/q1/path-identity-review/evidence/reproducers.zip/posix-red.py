import json
import runpy
import tempfile
from pathlib import Path

root=Path(__file__).resolve().parents[2]
helpers=runpy.run_path(str(root/'infra/repo_utils/path_utils.py'))
with tempfile.TemporaryDirectory() as folder:
    repo=Path(folder)
    literal=repo / 'a\\b.py'
    nested=repo / 'a/b.py'
    nested.parent.mkdir()
    literal.write_text('literal')
    nested.write_text('nested')
    relative=helpers['to_relative_path'](literal, repo)
    restored=Path(helpers['to_absolute_path'](relative, repo))
    print(json.dumps({'relative':relative,'literal':str(literal),'restored':str(restored),'distinct_original_files':not literal.samefile(nested),'roundtrip_same_file':literal.samefile(restored),'restored_content':restored.read_text()}))
    assert literal.samefile(restored), 'POSIX backslash filename changed identity'
